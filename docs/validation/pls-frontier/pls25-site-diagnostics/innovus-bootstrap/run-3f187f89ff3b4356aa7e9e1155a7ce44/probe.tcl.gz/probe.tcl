puts "CAP_SIZEOF [info commands sizeof_collection]"
puts "CAP_GET_LIB_CELLS [info commands get_lib_cells]"
puts "CAP_WRITE_SDC [info commands write_sdc]"
exit
