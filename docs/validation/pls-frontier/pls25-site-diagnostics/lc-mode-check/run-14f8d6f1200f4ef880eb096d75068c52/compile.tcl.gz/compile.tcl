read_lib {/data/eda/project/hima_harness/polishing-runs/dtco-selected-1789286963812287000/flow/artifacts/characterize/run-bfe84c7387cd441caea9fd6f00b1ecdd/generated.lib}
puts "=== AES_DTCO LC READ COMPLETE ==="
check_library
puts "=== AES_DTCO LC CHECK COMPLETE ==="
write_lib -format db aes_dtco_generated -output {/data/eda/project/hima_harness/polishing-runs/dtco-selected-1789286963812287000/flow/artifacts/lc-mode-check/run-14f8d6f1200f4ef880eb096d75068c52/aes_dtco_generated.db}
puts "=== AES_DTCO LC WRITE COMPLETE ==="
exit
