read_lib {/data/eda/project/hima_harness/polishing-runs/dtco-selected-1789286963812287000/flow/artifacts/characterize/run-bfe84c7387cd441caea9fd6f00b1ecdd/generated.lib}
puts "=== AES_DTCO LC READ COMPLETE ==="
check_library
puts "=== AES_DTCO LC CHECK COMPLETE ==="
write_lib -format db aes_dtco_generated -output {/data/eda/project/hima_harness/polishing-runs/dtco-selected-1789286963812287000/flow/artifacts/lc-environment-check/run-dd5c66f5a0084cf2ad4e7533c8d93fb8/aes_dtco_generated.db}
puts "=== AES_DTCO LC WRITE COMPLETE ==="
exit
