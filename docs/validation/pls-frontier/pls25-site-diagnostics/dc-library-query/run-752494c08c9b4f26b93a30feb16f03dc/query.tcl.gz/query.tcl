read_db {/data/eda/project/hima_harness/polishing-runs/dtco-selected-1789286963812287000/flow/artifacts/compile/run-e7bf88e1a9d7437d84acc7d305d5fbbb/aes_dtco_generated.db}
puts "UNQUALIFIED [sizeof_collection [get_lib_cells -quiet XS_*]]"
puts "QUALIFIED [sizeof_collection [get_lib_cells -quiet */XS_*]]"
puts "MASTERS [get_object_name [get_lib_cells -quiet */XS_*]]"
exit
