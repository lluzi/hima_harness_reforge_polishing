read_lib {/data/eda/project/hima_harness/polishing-runs/dtco-selected-1789286963812287000/flow/artifacts/characterize/run-bfe84c7387cd441caea9fd6f00b1ecdd/generated.lib}
write_lib -format db aes_dtco_generated -output {/data/eda/project/hima_harness/polishing-runs/dtco-selected-1789286963812287000/flow/artifacts/lc-isolation/run-c917f897a28145c08841ac508bf6eafd/read-write.db}
exit
