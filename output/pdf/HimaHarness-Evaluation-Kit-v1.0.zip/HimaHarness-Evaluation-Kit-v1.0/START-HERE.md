# 从这里开始

本资料包对应 HimaHarness v0.2.0-trial.1。

1. 阅读 PDF，或双击 evaluation-handbook.html 打开离线阅读版。
2. 交接人先填写 admin-handover.md；没有准备好的 Site/素材时，从普通编码路线开始。
3. 评估者复制 evaluation-worksheet.md 或 evaluation-scores.csv 填写，保留空白模板。
4. HTML 页内导航可用，提示词推荐从 HTML/Markdown 复制。

下载应用：https://github.com/lluzi/hima_harness_reforge_polishing/releases/tag/v0.2.0-trial.1

这里没有应用二进制、密钥、PDK、私有研究资产或本机专用配置。模型调用和真实 EDA 都需要相应准备与授权；任务时间安排不是金额上限。

SHA256SUMS.txt 可用于核对本包文件。验证记录为 validation.json，不代表重新跑过产品实验。
